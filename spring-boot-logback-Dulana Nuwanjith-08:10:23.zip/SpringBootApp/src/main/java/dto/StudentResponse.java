package dto;

import lombok.Setter;

@Setter
public class StudentResponse {
    private String id;
    private String name;
    private String dateOfBirth;
    private double average;

}
