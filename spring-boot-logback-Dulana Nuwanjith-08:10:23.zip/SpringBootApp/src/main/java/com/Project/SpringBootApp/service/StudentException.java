package com.Project.SpringBootApp.service;

public class StudentException extends RuntimeException{
    public StudentException(String message){
        super(message);
    }

}
